﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            clear = new Button();
            button_divide = new Button();
            button16 = new Button();
            button_subtract = new Button();
            plus = new Button();
            button_factorial = new Button();
            button_power = new Button();
            button_sqrroot = new Button();
            button_modulo = new Button();
            button23 = new Button();
            pictureBox1 = new PictureBox();
            textbox = new Label();
            history = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 19.8000011F);
            button1.ForeColor = SystemColors.ActiveBorder;
            button1.Location = new Point(97, 476);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(88, 57);
            button1.TabIndex = 0;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 19.8000011F);
            button2.ForeColor = SystemColors.ActiveBorder;
            button2.Location = new Point(191, 476);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(88, 57);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Transparent;
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 19.8000011F);
            button3.ForeColor = SystemColors.ActiveBorder;
            button3.Location = new Point(285, 476);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(88, 57);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Transparent;
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 19.8000011F);
            button4.ForeColor = SystemColors.ActiveBorder;
            button4.Location = new Point(97, 414);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(88, 57);
            button4.TabIndex = 3;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Transparent;
            button5.BackgroundImageLayout = ImageLayout.None;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 19.8000011F);
            button5.ForeColor = SystemColors.ActiveBorder;
            button5.Location = new Point(191, 414);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(88, 57);
            button5.TabIndex = 4;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Transparent;
            button6.BackgroundImageLayout = ImageLayout.None;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 19.8000011F);
            button6.ForeColor = SystemColors.ActiveBorder;
            button6.Location = new Point(285, 414);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(88, 57);
            button6.TabIndex = 5;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.Transparent;
            button7.BackgroundImageLayout = ImageLayout.None;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 19.8000011F);
            button7.ForeColor = SystemColors.ActiveBorder;
            button7.Location = new Point(97, 352);
            button7.Margin = new Padding(3, 2, 3, 2);
            button7.Name = "button7";
            button7.Size = new Size(88, 57);
            button7.TabIndex = 7;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.Transparent;
            button8.BackgroundImageLayout = ImageLayout.None;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 19.8000011F);
            button8.ForeColor = SystemColors.ActiveBorder;
            button8.Location = new Point(191, 352);
            button8.Margin = new Padding(3, 2, 3, 2);
            button8.Name = "button8";
            button8.Size = new Size(88, 57);
            button8.TabIndex = 7;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.Transparent;
            button9.BackgroundImageLayout = ImageLayout.None;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 19.8000011F);
            button9.ForeColor = SystemColors.ActiveBorder;
            button9.Location = new Point(285, 352);
            button9.Margin = new Padding(3, 2, 3, 2);
            button9.Name = "button9";
            button9.Size = new Size(88, 57);
            button9.TabIndex = 8;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click_1;
            // 
            // button10
            // 
            button10.BackColor = Color.Transparent;
            button10.BackgroundImageLayout = ImageLayout.None;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 19.8000011F);
            button10.ForeColor = SystemColors.ActiveBorder;
            button10.Location = new Point(379, 476);
            button10.Margin = new Padding(3, 2, 3, 2);
            button10.Name = "button10";
            button10.Size = new Size(88, 119);
            button10.TabIndex = 9;
            button10.Text = "=";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.Transparent;
            button11.BackgroundImageLayout = ImageLayout.None;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Font = new Font("Segoe UI", 19.8000011F);
            button11.ForeColor = SystemColors.ActiveBorder;
            button11.Location = new Point(191, 538);
            button11.Margin = new Padding(3, 2, 3, 2);
            button11.Name = "button11";
            button11.Size = new Size(88, 57);
            button11.TabIndex = 10;
            button11.Text = "0";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.BackColor = Color.Transparent;
            button12.BackgroundImageLayout = ImageLayout.None;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Font = new Font("Segoe UI", 19.8000011F);
            button12.ForeColor = SystemColors.ActiveBorder;
            button12.Location = new Point(97, 538);
            button12.Margin = new Padding(3, 2, 3, 2);
            button12.Name = "button12";
            button12.Size = new Size(88, 57);
            button12.TabIndex = 11;
            button12.Text = "+/-";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.Transparent;
            button13.BackgroundImageLayout = ImageLayout.None;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Font = new Font("Segoe UI", 19.8000011F);
            button13.ForeColor = SystemColors.ActiveBorder;
            button13.Location = new Point(285, 538);
            button13.Margin = new Padding(3, 2, 3, 2);
            button13.Name = "button13";
            button13.Size = new Size(88, 57);
            button13.TabIndex = 12;
            button13.Text = ",";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // clear
            // 
            clear.BackColor = Color.Transparent;
            clear.BackgroundImageLayout = ImageLayout.None;
            clear.FlatStyle = FlatStyle.Flat;
            clear.Font = new Font("Segoe UI", 19.8000011F);
            clear.ForeColor = SystemColors.ActiveBorder;
            clear.Location = new Point(379, 352);
            clear.Margin = new Padding(3, 2, 3, 2);
            clear.Name = "clear";
            clear.Size = new Size(88, 119);
            clear.TabIndex = 13;
            clear.Text = "CE";
            clear.UseVisualStyleBackColor = false;
            clear.Click += clear_Click;
            // 
            // button_divide
            // 
            button_divide.BackColor = Color.Transparent;
            button_divide.BackgroundImageLayout = ImageLayout.None;
            button_divide.FlatStyle = FlatStyle.Flat;
            button_divide.Font = new Font("Segoe UI", 19.8000011F);
            button_divide.ForeColor = SystemColors.ActiveBorder;
            button_divide.Location = new Point(285, 290);
            button_divide.Margin = new Padding(3, 2, 3, 2);
            button_divide.Name = "button_divide";
            button_divide.Size = new Size(88, 57);
            button_divide.TabIndex = 14;
            button_divide.Text = "/";
            button_divide.UseVisualStyleBackColor = false;
            button_divide.Click += button_divide_Click;
            // 
            // button16
            // 
            button16.BackColor = Color.Transparent;
            button16.BackgroundImageLayout = ImageLayout.None;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Font = new Font("Segoe UI", 19.8000011F);
            button16.ForeColor = SystemColors.ActiveBorder;
            button16.Location = new Point(191, 290);
            button16.Margin = new Padding(3, 2, 3, 2);
            button16.Name = "button16";
            button16.Size = new Size(88, 57);
            button16.TabIndex = 17;
            button16.Text = "×";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button_subtract
            // 
            button_subtract.BackColor = Color.Transparent;
            button_subtract.BackgroundImageLayout = ImageLayout.None;
            button_subtract.FlatStyle = FlatStyle.Flat;
            button_subtract.Font = new Font("Segoe UI", 19.8000011F);
            button_subtract.ForeColor = SystemColors.ActiveBorder;
            button_subtract.Location = new Point(97, 290);
            button_subtract.Margin = new Padding(3, 2, 3, 2);
            button_subtract.Name = "button_subtract";
            button_subtract.Size = new Size(88, 57);
            button_subtract.TabIndex = 15;
            button_subtract.Text = "-";
            button_subtract.UseVisualStyleBackColor = false;
            button_subtract.Click += button_subtract_Click;
            // 
            // plus
            // 
            plus.BackColor = Color.Transparent;
            plus.BackgroundImageLayout = ImageLayout.None;
            plus.FlatStyle = FlatStyle.Flat;
            plus.Font = new Font("Segoe UI", 19.8000011F);
            plus.ForeColor = SystemColors.ActiveBorder;
            plus.Location = new Point(3, 290);
            plus.Margin = new Padding(3, 2, 3, 2);
            plus.Name = "plus";
            plus.Size = new Size(88, 57);
            plus.TabIndex = 16;
            plus.Text = "+";
            plus.UseVisualStyleBackColor = false;
            plus.Click += button18_Click;
            // 
            // button_factorial
            // 
            button_factorial.BackColor = Color.Transparent;
            button_factorial.BackgroundImageLayout = ImageLayout.None;
            button_factorial.FlatStyle = FlatStyle.Flat;
            button_factorial.Font = new Font("Segoe UI", 19.8000011F);
            button_factorial.ForeColor = SystemColors.ActiveBorder;
            button_factorial.Location = new Point(3, 352);
            button_factorial.Margin = new Padding(3, 2, 3, 2);
            button_factorial.Name = "button_factorial";
            button_factorial.Size = new Size(88, 57);
            button_factorial.TabIndex = 18;
            button_factorial.Text = "n!";
            button_factorial.UseVisualStyleBackColor = false;
            button_factorial.Click += button_factorial_Click;
            // 
            // button_power
            // 
            button_power.BackColor = Color.Transparent;
            button_power.BackgroundImageLayout = ImageLayout.None;
            button_power.FlatStyle = FlatStyle.Flat;
            button_power.Font = new Font("Segoe UI", 19.8000011F);
            button_power.ForeColor = SystemColors.ActiveBorder;
            button_power.Location = new Point(3, 414);
            button_power.Margin = new Padding(3, 2, 3, 2);
            button_power.Name = "button_power";
            button_power.Size = new Size(88, 57);
            button_power.TabIndex = 19;
            button_power.Text = "x^y";
            button_power.UseVisualStyleBackColor = false;
            button_power.Click += button_power_Click;
            // 
            // button_sqrroot
            // 
            button_sqrroot.BackColor = Color.Transparent;
            button_sqrroot.BackgroundImageLayout = ImageLayout.None;
            button_sqrroot.FlatStyle = FlatStyle.Flat;
            button_sqrroot.Font = new Font("Segoe UI", 19.8000011F);
            button_sqrroot.ForeColor = SystemColors.ActiveBorder;
            button_sqrroot.Location = new Point(3, 476);
            button_sqrroot.Margin = new Padding(3, 2, 3, 2);
            button_sqrroot.Name = "button_sqrroot";
            button_sqrroot.Size = new Size(88, 57);
            button_sqrroot.TabIndex = 20;
            button_sqrroot.Text = "x√y";
            button_sqrroot.UseVisualStyleBackColor = false;
            button_sqrroot.Click += button_sqrroot_Click;
            // 
            // button_modulo
            // 
            button_modulo.BackColor = Color.Transparent;
            button_modulo.BackgroundImageLayout = ImageLayout.None;
            button_modulo.FlatStyle = FlatStyle.Flat;
            button_modulo.Font = new Font("Segoe UI", 19.8000011F);
            button_modulo.ForeColor = SystemColors.ActiveBorder;
            button_modulo.Location = new Point(3, 538);
            button_modulo.Margin = new Padding(3, 2, 3, 2);
            button_modulo.Name = "button_modulo";
            button_modulo.Size = new Size(88, 57);
            button_modulo.TabIndex = 21;
            button_modulo.Text = "%";
            button_modulo.UseVisualStyleBackColor = false;
            button_modulo.Click += button_modulo_Click;
            // 
            // button23
            // 
            button23.BackColor = Color.Transparent;
            button23.BackgroundImageLayout = ImageLayout.None;
            button23.FlatStyle = FlatStyle.Flat;
            button23.Font = new Font("Segoe UI", 19.8000011F);
            button23.ForeColor = SystemColors.ActiveBorder;
            button23.Location = new Point(379, 290);
            button23.Margin = new Padding(3, 2, 3, 2);
            button23.Name = "button23";
            button23.Size = new Size(88, 57);
            button23.TabIndex = 22;
            button23.Text = "DEL";
            button23.UseVisualStyleBackColor = false;
            button23.Click += button23_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.smrckabat;
            pictureBox1.Location = new Point(173, 43);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(124, 117);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // textbox
            // 
            textbox.AutoSize = true;
            textbox.BackColor = Color.Transparent;
            textbox.BorderStyle = BorderStyle.Fixed3D;
            textbox.FlatStyle = FlatStyle.Flat;
            textbox.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point, 238);
            textbox.ForeColor = Color.Transparent;
            textbox.Location = new Point(3, 190);
            textbox.MaximumSize = new Size(464, 80);
            textbox.MinimumSize = new Size(464, 80);
            textbox.Name = "textbox";
            textbox.Size = new Size(464, 80);
            textbox.TabIndex = 26;
            textbox.TextAlign = ContentAlignment.TopRight;
            // 
            // history
            // 
            history.AutoSize = true;
            history.BackColor = Color.Transparent;
            history.BorderStyle = BorderStyle.Fixed3D;
            history.FlatStyle = FlatStyle.Flat;
            history.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point, 238);
            history.ForeColor = Color.Transparent;
            history.Location = new Point(3, 30);
            history.MaximumSize = new Size(464, 145);
            history.MinimumSize = new Size(464, 145);
            history.Name = "history";
            history.Size = new Size(464, 145);
            history.TabIndex = 27;
            history.TextAlign = ContentAlignment.TopRight;
            history.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.Black;
            BackgroundImage = Properties.Resources.dark_fade;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(474, 603);
            Controls.Add(pictureBox1);
            Controls.Add(textbox);
            Controls.Add(history);
            Controls.Add(button23);
            Controls.Add(button_modulo);
            Controls.Add(button_sqrroot);
            Controls.Add(button_power);
            Controls.Add(button_factorial);
            Controls.Add(button16);
            Controls.Add(button_subtract);
            Controls.Add(plus);
            Controls.Add(button_divide);
            Controls.Add(clear);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            KeyDown += Form1_KeyDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button clear;
        private Button button_divide;
        private Button button16;
        private Button button_subtract;
        private Button plus;
        private Button button_factorial;
        private Button button_power;
        private Button button_sqrroot;
        private Button button_modulo;
        private Button button23;
        private PictureBox pictureBox1;
        private Label textbox;
        private Label history;
    }
}
